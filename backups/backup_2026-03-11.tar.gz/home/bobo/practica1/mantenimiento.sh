#!/bin/bash

echo "Inicio mantenimiento $(date)"

date

sudo apt update
sudo apt upgrade -y

mkdir -p ~/backups

tar -czf ~/backups/backup_$(date +%F).tar.gz /etc /home

find /var/log -type f -mtime +7 -delete

echo "Mantenimiento completado $(date)"


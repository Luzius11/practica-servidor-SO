exit
sudo vim /usr/local/bin/opse
ope
opse
sudo chmod +x /usr/local/bin/opse
opse
exit
hola
ls
cd .
cd ..
ls
cd ..
ls
cd bin
ls
cd
cd ..
cd bin
cd opse
cat opse
cd local
cd 
sudo apt update
sudo apt update -y
lsb_release -a
mkdir practica1
ls
cd practica1
cd
ls
cd practica1
ls
ls
ls -l
cd /usr/local/bin/opse
cd /usr/local/bin
ls
rm opse
sudo rm opse
rm -r
rm -r opse
rm opse
rm -f opse
ls
cd 
cd ~
lsb_release -a
ls
mkdir martatequiero
rm -f martatequiero
rm -r martatequiero
cd practica1
vim mantenimiento.sh
chmod +x mantenimiento.sh
mantenimiento.sh
./mantenimiento.sh
echo hola
crontab -e
contrab -l
crontab -l
vim mantenimiento.sh
sudo apt install nginx -y
systemctl status nginx
q
cd /var/www/html
ls
sudo vim index.html
sudo apt install python3 python3-venv python3-pip -y
mkdir api
cd api
cd
cd practica
cd practica1/
mkdir api
cd api
python3 -m venv venv
source venv/bin/activate
pip install bottle
vim app.py
python3 app.py
sudo apt install supervisor 
systemctl status supervisor
sudo vim /etc/supervisor/conf.d/api.conf
sudo supervisorctl reread
sudo supervisorctl update
status
sudo supervisorctl status
sudo vim /etc/nginx/sites-available/default
sudo system restart nginx
cd
cd practica1/
sudo system restart nginx
sudo systemctl restart nginx
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx
sudo vim index.html
cd /var/www/html
sudo vim index.html
sudo apt install git -y
git --version
cd practica1
git init
vim .gitignore
git add .
git commit -m "Practia 1 servidor linux"
git@github.com:Luzius11/practica-servidor-SO.git
git remote add origin git@github.com:Luzius11/practica-servidor-SO.git
git push -u origin main
git remote add origin https://github.com/Luzius11/practica-servidor-SO.git
git push -u origin main
git clone git@github.com:Luzius11/practica-servidor-SO.git
ls ~/.ssh
ssh-keygen -t ed25519 -C "luisnor777@gmail.com"
cat ~/.ssh/id_ed25519.pub
ssh -T git@github.com
git clone git@github.com:Luzius11/practica-servidor-SO.git
ls 
cd practica-servidor-SO/
cp ~/practica1/mantenimiento.sh .
cp ~/practica1/api .
ls
cpdir ~/practica1/api .
cp -d ~/practica1/api .
cp -f ~/practica1/api .
cp -r ~/practica1/api .
cp ~/practica1/README .
cp ~/practica1/documentacion .
cd
cd practica1/
ls
cd api
ls
cd
cd practica1/
cd practica-servidor-SO/
ls
git add .
git commit -m "PRUEBA"
git push
git pull origin main --allow-unrelated-histories
git push origin main
git pull origin main --allow-unrelated-histories
git pull origin main --allow-unrelated-histories --no-rebase
git push origin main
cd
cd practica1/
ls
cd .git/
ls
cd 
cd ~/practica1/practica-servidor-SO
nano .gitignore
git rm -r --cached api/venv
git add .
git commit -m "Remove venv and add gitignore"
git push origin main
cd practica1/
sudo vim /etc/nginx/sites-available/default
opse
exit
